from django.http.response import HttpResponse
from django.shortcuts import render
from .forms import *

# Create your views here.
def homeView(request):
    # return render(request,'Home/base.html')
    return render(request,'Home/home.html')

def category_View(request):
    if request.method == "GET":
        categoryfrm=Category_Form()
        d1={'categorydata':categoryfrm}
        return  render(request,'Home/category.html',context=d1)
    elif request.method == "POST":
        categoryfrm=Category_Form(request.POST,request.FILES)
        d1={'categorydata':categoryfrm}
        if categoryfrm.is_valid():
            categoryfrm.save()
            # msg='category updated successfully...'
            # d1['message':msg]
            # return  render(request,'Home/category.html',context=d1)
            return HttpResponse('added..')
        else:
            return render(request,'Home/category.html',context=d1)
def brand_View(request):
    if request.method == "GET":
        brandfrm=Brand_Form()
        d1={'branddata':brandfrm}
        return  render(request,'Home/brand.html',context=d1)
    elif request.method == "POST":
        brandfrm=Brand_Form(request.POST,request.FILES)
        d1={'branddata':brandfrm}
        if brandfrm.is_valid():
            brandfrm.save()
            return HttpResponse('success')
        else:
            return  render(request,'Home/brand.html',context=d1)
def products_View(request):
    if request.method == "GET":
        productsfrm=Products_Form()
        d1={'productdata':productsfrm}
        return  render(request,'Home/products.html',context=d1)
def order_View(request):
    if request.method == "GET":
        orderfrm=Order_Form()
        d1={'orderdata':orderfrm}
        return  render(request,'Home/order.html',context=d1)
def cart_View(request):
    if request.method == "GET":
        cartfrm=Cart_Form()
        d1={'cartdata':cartfrm}
        return  render(request,'Home/cart.html',context=d1)
def otpView(request):
    if request.method == "GET":
        otpfrm=OTP_Form()
        d1={'otpdata':otpfrm}
        return  render(request,'Home/otp.html',context=d1)
def order_details_View(request):
    if request.method == "GET":
        orderdetailsfrm=Order_details_Form()
        d1={'orderdetailsdata':orderdetailsfrm}
        return  render(request,'Home/order_details.html',context=d1)