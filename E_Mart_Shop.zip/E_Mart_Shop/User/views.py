from django.http.response import HttpResponse
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from User.forms import myuserForm

# Create your views here.

def userView(request):
    if request.method=="GET":
        myuser_form = myuserForm()
        new_user = UserCreationForm()
        d1 = {'myuser':myuser_form,'newuser':new_user}
        return render(request,'User/user.html',context=d1)
    elif request.method=="POST":
        myuser_form = myuserForm(request.POST,request.FILES)
        new_user = UserCreationForm(request.POST)
        d1 = {'myuser':myuser_form,'newuser':new_user}
        if myuser_form.is_valid() and new_user.is_valid():
            U_user = new_user.save()
            U_user.save()
            M_user=myuser_form.save(commit=False)
            M_user.user=U_user
            M_user.save()
            return HttpResponse('Account created Successfully...')
        else:
            return render(request,'User/user.html',context=d1)