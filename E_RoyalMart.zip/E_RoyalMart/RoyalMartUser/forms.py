from django import forms
from django.forms import fields
from.models import *

class SellersForm(forms.ModelForm):
    class Meta:
        model=Sellers
        # fields="__all__"
        exclude=['user']
class BuyersForm(forms.ModelForm):
    class Meta:
        model=Buyer
        # fields="__all__"
        exclude=['user']