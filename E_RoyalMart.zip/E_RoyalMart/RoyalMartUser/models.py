from django.db import models
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import pre_save,post_save


# Create your models here.


class Sellers(models.Model):
    name = models.CharField(max_length=50)
    email_id = models.CharField(max_length=50,null=True,blank=True)
    mobile_no = models.CharField(max_length=20)
    image = models.ImageField(upload_to='RoyalMartUser/img', max_length=120,null=True,blank=True)
    user_status = models.CharField( max_length=50,default=0)
    created_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)
    user=models.OneToOneField(User,on_delete=models.CASCADE)

    def __str__(self):
        return str(self.name)


class Buyer(models.Model):
    name = models.CharField(max_length=50)
    email_id = models.CharField(max_length=50,null=True,blank=True)
    mobile_no = models.CharField(max_length=20)
    # user_status = models.CharField( max_length=50)
    created_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)
    user=models.OneToOneField(User,on_delete=models.CASCADE)

class Address(models.Model):
    city = models.CharField( max_length=50)
    state = models.CharField( max_length=50)
    pincode = models.IntegerField()
    user = models.ForeignKey(User,on_delete=models.CASCADE)