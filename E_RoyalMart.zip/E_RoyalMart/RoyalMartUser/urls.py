from django.urls import path
from .views import *


urlpatterns = [
    path('seller/', sellerView,name='seller'),
    path('buyer/', buyerView,name='buyer'),
]
