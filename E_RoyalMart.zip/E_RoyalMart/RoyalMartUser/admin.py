from django.contrib import admin
from RoyalMartUser.models import Buyer, Sellers

# Register your models here.

class sellerAdmin(admin.ModelAdmin):
    admin.site.register(Sellers)
class buyerAdmin(admin.ModelAdmin):
    admin.site.register(Buyer)

