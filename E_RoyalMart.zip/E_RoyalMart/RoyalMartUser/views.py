from django.http.response import HttpResponse
from .forms import *
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm



# Create your views here.
def sellerView(request):
    # return HttpResponse('user login')
    # d1={}
    if request.method=='GET':
        Sform=SellersForm()
        Uform=UserCreationForm
        d1={'sellerform':Sform,'userform':Uform}
        return render(request,'RoyalmartUser/sellers.html',context=d1)
    elif request.method=='POST':
        Sform=SellersForm(request.POST)
        Uform=UserCreationForm(request.POST)
        d1={'sellerform':Sform,'userform':Uform}
        if Sform.is_valid and Uform.is_valid:
            u=Uform.save()
            u.save()
            s = Sform.save(commit=False)
            s.user = u
            s.save()
            return HttpResponse('saller acount created...')
        else:        
            return render(request,'RoyalmartUser/sellers.html',context=d1)

def buyerView(request):
    # return HttpResponse('user login')
    # d1={}
    if request.method=='GET':
        Bform=BuyersForm()
        Uform=UserCreationForm
        d1={'buyerform':Bform,'userform':Uform}
        return render(request,'RoyalmartUser/buyer.html',context=d1)
    elif request.method=='POST':
        Bform=BuyersForm(request.POST)
        Uform=UserCreationForm(request.POST)
        d1={'buyerform':Bform,'userform':Uform}
        if Bform.is_valid and Uform.is_valid:
            u=Uform.save()
            u.save()
            b = Bform.save(commit=False)
            b.user = u
            b.save()
            return HttpResponse('buyer acount created...')
        else:        
            return render(request,'RoyalmartUser/buyer.html',context=d1)