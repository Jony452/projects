from django.db import models
from django.contrib.auth.models import User
from django.db.models.base import Model
from RoyalMartUser.models import *

# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=50)
    # status = models.CharField(max_length=50)
    # image = models.ImageField(null=True,blank=True,upload_to='Category_images')
    

class Brand(models.Model):
    name = models.CharField(max_length=50)
    # status = models.CharField(max_length=50)
    # image = models.ImageField(null=True,blank=True,upload_to='Brand_images')
    
    

class Products(models.Model):
    name = models.CharField( max_length=50)
    actual_price = models.IntegerField()
    # image = models.ImageField( upload_to='Products_image', null = True, blank = True)
    selling_price = models.IntegerField()
    seller = models.ForeignKey(Sellers,on_delete=models.CASCADE)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE)

class OTP(models.Model):
    reference_no = models.CharField(max_length=50, unique=True)
    # otp = models.CharField(max_length=6)
    creation_time = models.DateTimeField(auto_now_add=True)
    # is_issued = models.DateTimeField(auto_now=True)

class Order(models.Model):
    creation_date = models.DateTimeField(auto_now_add=True)
    buyer = models.ForeignKey(Buyer,on_delete=models.CASCADE)
    # order_status = 

class Order_Details(models.Model):
    order = models.ForeignKey(Order,on_delete=models.CASCADE)
    product = models.ForeignKey(Products,on_delete=models.CASCADE)
    quantity = models.IntegerField()
    # price = Products.selling_price
    actual_price = models.IntegerField()
    selling_price = models.IntegerField()
    discount = models.IntegerField()
    actual_paid_amount = models.IntegerField()

class Cart(models.Model):
    product_id = models.CharField(unique=True, max_length=50)
    creation_date = models.DateTimeField(auto_now_add=True)
    # product_status = ?
    user = models.OneToOneField(Buyer,on_delete=models.CASCADE)
