from django.conf import urls
from customer.forms import Add_cus_using_form
from customer.models import Customer
from django.http.response import HttpResponse
from django.shortcuts import render
import json
import requests
from customer.serializer import customer_serializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view

# Create your views here.

def fView(request):
    return render(request, 'customer/boost.html')

def addcusView(request):
    # return HttpResponse('add customer here')
    d1={}
    if request.method == "GET":
        Cus_Form = Add_cus_using_form()
        d1['form'] = Cus_Form
        return render(request, 'customer/boost.html', context=d1)
    elif request.method == "POST":
        Cus_Form = Add_cus_using_form(request.POST)
        d1['form'] = Cus_Form
        if Cus_Form.is_valid:
            Cus_Form.save()
        return HttpResponse("added...")
    else:
        return render(request, 'customer/boost.html', context=d1)


# def get_customer_view(request,id):
#     # cus = Customer.objects.get(id=id)
#     cus = Customer.objects.all()
#     cus_native = customer_serializer(cus,many = True) # serialization
#     cus_json = json.dumps(cus_native.data)
#     resp =  HttpResponse(cus_json,content_type='application/json')
#     return resp

@api_view(http_method_names=["GET"])
def get_customer_by_id(request,id):
    try:
        cus= Customer.objects.all()
        cus_native = customer_serializer(cus,many=True)
        resp = Response(data=cus_native.data,status=status.HTTP_200_OK)
        return resp
    except Exception as e:
        resp = Response(data=str(e),status=status.HTTP_404_NOT_FOUND)
        return resp

def Air_Quality_check(request):
    if request.method=='GET':
        return render(request,'customer/get_air_quality.html')
    elif request.method=='POST':
        lat=request.POST.get('lat_data')
        lon=request.POST.get('lon_data')
        hours=request.POST.get('hour_data')
        url = "https://air-quality.p.rapidapi.com/forecast/airquality"
        params= {"lat":lat,"lon":lon,"hours":hours}
        headers={'x-rapidapi-host': "air-quality.p.rapidapi.com",'x-rapidapi-key': "b898455d4cmsh814e9850cd2e09cp1c5ec6jsn2fcaf13b1f2a"}
        resp=requests.get(url,params=params,headers=headers)
        d1={'api_data':resp.text}
        return render(request,'customer/get_air_quality.html',context=d1)