from django.urls import path
from.views import *

urlpatterns = [
    path('', fView),
    path('addcustomer/', addcusView),
    # path('rest/<int:id>',get_customer_view,name='get_customer'),
    path('restapi/<int:id>',get_customer_by_id),
    path('aqi/',Air_Quality_check)
]
