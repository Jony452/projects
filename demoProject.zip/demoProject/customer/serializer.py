# from rest_framework.serializers import Serializer
from rest_framework import serializers

from customer.models import Customer


# class customer_serializer(serializers.Serializer):
#     name = serializers.CharField()
#     address = serializers.CharField()
#     moblino = serializers.CharField()  
#     email = serializers.CharField()

class customer_serializer(serializers.ModelSerializer):
    class Meta:
        model=Customer
        fields = '__all__'
