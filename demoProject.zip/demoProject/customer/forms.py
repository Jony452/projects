from django import forms
from django.db.models import fields
from django.forms.models import ModelForm
from.models import *

class Add_cus_using_form(forms.ModelForm):
    class Meta:
        model = Customer
        fields = "__all__"