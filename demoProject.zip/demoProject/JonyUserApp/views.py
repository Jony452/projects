from django.http.response import HttpResponse
from django.shortcuts import render
from.models import *

# Create your views here.

def Sview(request):
    return render(request,'JonyUserApp/user.html')
    # return HttpResponse("This is user app")

def adduser(request):    
    return render(request,'JonyUserApp/addUser.html')

def loginView(request):
    if request.method== "POST":
        email=request.POST.get('email')
        password= request.POST.get('password')
        print('Email', email)
        print('password',password)    
    return render(request,'JonyUserApp/loginpage.html')


