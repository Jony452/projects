from django.contrib import admin
from django.urls import path
from django.http.response import HttpResponse
from django.urls.conf import include
from JonyUserApp import views

    

# Base url http://127.0.0.1:800/user

urlpatterns = [
    path('', views.Sview),
    path('adduser/', views.adduser),
    path('login/', views.loginView),

]


# python manage.py runserver