from django.apps import AppConfig


class JonyuserappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'JonyUserApp'
