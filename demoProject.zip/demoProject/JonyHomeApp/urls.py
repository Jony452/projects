from django.contrib import admin
from django.urls import path
from django.http.response import HttpResponse
from.views import *    

# Base url http://127.0.0.1:800/Jony

# def anyview(r):        #view
#     resp = HttpResponse("This is our Jony homepage App")
#     return resp

urlpatterns = [
    path('', anyview,),
    path('training/', trainingview),
    path('training/python', pythonView),
    path('restapi/<int:id>', get_student_by_id),
    path('covid-19/', get_covid_19_data),
    path('covid-ajax/', get_covid_19_data_using_ajax),


]


#python manage.py runserver

