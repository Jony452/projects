from django.http.response import HttpResponse
from django.shortcuts import render
import rest_framework
import requests
from JonyHomeApp.serializer import Student_Serializer
from .models import Student
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here.


def anyview(request):       
    return render(request,'JonyHomeApp/home.html')
    # resp = HttpResponse("This is our Jony homepage App..")
    # return resp

def trainingview(request):       
    return render(request,'JonyHomeApp/training.html')

def pythonView(request):        
    return render(request,'JonyHomeApp/python.html')

@api_view(http_method_names=['GET'])
def get_student_by_id(request,id): 
    try: 
        student=Student.objects.all()
        student_native=  Student_Serializer(student,many=True)
        resp=Response(data=student_native.data,status=status.HTTP_200_OK)  
        return resp
    except Exception as E:
        resp=Response(data=str(E),status=status.HTTP_400_BAD_REQUEST) 

def get_covid_19_data(request):
    if request.method=="GET":       
        return render(request,'JonyHomeApp/get_covid_19_data.html')
    elif request.method=="POST":
        code=request.POST.get('code')
        params={"code":code}
        url = "https://covid-19-data.p.rapidapi.com/country/code"
        headers = {'x-rapidapi-host': "covid-19-data.p.rapidapi.com",'x-rapidapi-key': "b898455d4cmsh814e9850cd2e09cp1c5ec6jsn2fcaf13b1f2a"}
        resp_api= requests.get(url,params=params,headers=headers)
        d1={'covid_data':resp_api.text}
        return render(request,'JonyHomeApp/get_covid_19_data.html',context=d1)
    else:
        return render(request,'JonyHomeApp/get_covid_19_data.html')

def get_covid_19_data_using_ajax(request):       
    return render(request,'JonyHomeApp/get_covid_data_using_ajax.html')