from django.urls import path
from.views import *



urlpatterns = [
    path('', HomeView, name='home'),
    path('var/', variable_ex, name='variable'),
    path('tag/', tagsView, name='tag'),
    path('filter/', filterView, name='filters'),
    path('writesession/',WritesessionView),
    path('readsession/',ReadsessionView),
]
