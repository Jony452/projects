from django import template
register = template.Library()


# make your filters here

def MyFil(value):
    return value.upper()
register.filter('Upper',MyFil)


@register.filter(name='space')
def Space_words(value,string):
    return value.replace(' ', string)

# {{'hello world' | Upper}}   yaha pe use hua h html file me
# {{"Jony Kumar Saini" | space:"_"}}