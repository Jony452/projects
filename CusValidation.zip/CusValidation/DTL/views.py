from Home.models import Customer
from django.shortcuts import render
from Home.views import *

# Create your views here.

def HomeView(request):
    return render(request,"DTL/home.html")

def variable_ex(request):
    d1 = {'var1': 'Hello Welcome to DTL Variables', 'var2': 'Here You learn Django Variable'}
    return render(request,"DTL/variable_example.html", context=d1)

def tagsView(request):
    return render(request,"DTL/tags.html")

def filterView(request):
    d1 = {}
    all_cus = Customer.objects.all()
    d1['student'] = all_cus
    return render(request,"DTL/filtersindtl.html",context=d1)

def WritesessionView(request):
    if request.method=="POST":
        request.session['Mydata'] = request.POST.get('txtdata')
        request.session.set_expiry(30)
    return render(request,'DTL/writeSession.html')

def ReadsessionView(request):
    return render(request,'DTL/readSession.html')

