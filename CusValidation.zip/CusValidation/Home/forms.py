from django import forms
from.models import *

class CustomerForm(forms.ModelForm):
    # gender = forms.ChoiceField(choices=[('male','MALE'),('female','FEMALE')])      # adding a field but value is not saved in database
    
    # def clean(self,*args, **kwargs):
    #    super().clean(*args, **kwargs)
    #    name1 = self.cleaned_data['name']
    #    email1 = self.cleaned_data['email_id']
    #    if name1 not in email1:
    #        raise ValidationError("name not in email...")

    def clean_name(self):
        data = self.cleaned_data["name"] 
        if ord(data[0])>=65 and ord(data[0])<=90:
            pass
        else:
            raise ValidationError("name should starts with capital letter")   
        return data
    

    class Meta:
        model = Customer
        fields = "__all__"


    def __init__(self,*args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['date_of_birth'].widget=forms.TextInput(attrs={'type': 'date'})
    # date_of_birth = forms.DateField(("Date"), default=DateInput)
    # email_id = forms.ChoiceField( choices=[('jony@cetpa.com','jony@cetpa.com'),('jony@scriet.com','jony@scriet.com')])   # modifying a field
