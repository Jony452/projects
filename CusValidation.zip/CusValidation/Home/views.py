from django.http.response import HttpResponse
from Home.forms import CustomerForm
from django.shortcuts import render
from Home.models import Customer
from Home.serializer import Customer_serializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view
import requests


# Create your views here.


def firstView(request):
    return render(request, 'Home/base.html')


def sampleView(request):
    return render(request, 'Home/sample.html')

def add_cusView(request):
    d1= {}
    if request.method=="GET":
        cus_form = CustomerForm()
        d1['form'] = cus_form
        return render(request, "Home/addcus.html", context=d1)
    elif request.method=="POST":
        cus_form = CustomerForm(request.POST)
        d1['form'] = cus_form
        if cus_form.is_valid:
            cus_form.save()
        return HttpResponse("added successfully...")
    else:
        return render(request,"Home/addcus.html", context=d1)

def session_writeView(request):
    if request.method =="POST":
        request.session['Mydata']=request.POST.get('text_data')
        request.session.set_expiry(10)


    resp = render(request,'Home/write_session.html')
    resp.set_cookie('mycookies','my data for cookies',max_age=20)
    return resp

def session_readView(request):
    cookies_data = request.COOKIES.get('mycookies','Cookies Expired')
    d1={'data':cookies_data}
    return render(request,'Home/read_session.html',contex=d1) 

    #api creating
@api_view(http_method_names=['GET'])
def Get_customer_id(request,id):
    try:
        # cus = Customer.objects.all()
        cus = Customer.objects.get(id=id)
        # cus_native = Customer_serializer(cus,many=True)  #serialization
        cus_native = Customer_serializer(cus)
        resp = Response(data=cus_native.data,status=status.HTTP_200_OK)
        return resp
    except Exception as e:
        resp = Response(data=str(e),status=status.HTTP_404_NOT_FOUND)
        return resp

def get_weather(request):
    if request.method=="GET":
        return render(request,'Home/weather_api.html')
    elif request.method=="POST":
        hours=request.POST.get('hours')
        lat=request.POST.get('lat')
        lon=request.POST.get('lon')
        # callback=request.POST.get('callback')
        # d=request.POST.get('d')
        # lang=request.POST.get('lang')
        # units=request.POST.get('units')
        # mode=request.POST.get('mode')
        url = "https://community-open-weather-map.p.rapidapi.com/weather"
        querystring = {"q":hours,"lat":lat,"lon":lon}
        header={'x-rapidapi-host': "community-open-weather-map.p.rapidapi.com",'x-rapidapi-key': "b898455d4cmsh814e9850cd2e09cp1c5ec6jsn2fcaf13b1f2a"}
        api_response=requests.get(url,params=querystring,headers=header)
        d1={'weather_data':api_response.text}
        return render(request,'Home/weather_api.html',context=d1)

@api_view(http_method_names=['POST'])
def post_save_cus_view(request):
    cus_deserialize=Customer_serializer(data=request.data)
    if cus_deserialize.is_valid():
        cus=cus_deserialize.save()
        return Response(data='Customer with id '+str(cus.id)+' created succsessfully.',status=status.HTTP_200_OK)
    else:
        return Response(data='Error!.... while adding Customer',status=status.HTTP_200_OK)