from django.db import models
from django.core import validators
from django.core.exceptions import ValidationError
# Create your models here.


# def mobile_val(value):
#     if value[0:1] != "9":
#         raise ValidationError((" no should start with 9"))

class Customer(models.Model):
    name = models.CharField(max_length=50)
    mobile_no = models.CharField( max_length=50)               
    # mobile_no = models.CharField( max_length=15, validators=[mobile_val])   # after this we should migrate
    email_id = models.CharField( max_length=50)
    date_of_birth = models.DateField()