from django.urls import path
from .views import *


urlpatterns = [
    path('', firstView),
    path('addcus/', add_cusView),
    path('sample/', sampleView, name="sample"),
    path('writesession/', session_writeView),
    path('readsession/', session_readView),
    path('restapi/<int:id>',Get_customer_id),
    path('weather/', get_weather),
    path('postsave/', post_save_cus_view),
    # path('ajax/',view_for_ajax),
]
