from django.urls import path
from .views import *

urlpatterns = [
    path('getcus/<int:id>',get_cus_by_id),
    path('aqi/',AQI_view),
    path('ajax/',AQI_view_ajax),
]
