from rest_framework import serializers

class Customer_Serializer(serializers.Serializer):
    # name = serializers.CharField()
    # mobile_no = serializers.CharField()               
    # email_id = serializers.CharField()
    # date_of_birth = serializers.DateField()
    name = serializers.CharField()
    address = serializers.CharField()
    date_of_birth = serializers.DateField()
    create_date = serializers.DateTimeField()
    update_date = serializers.DateTimeField()