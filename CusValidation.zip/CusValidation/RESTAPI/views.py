from django.http.response import HttpResponse
from django.shortcuts import render
from User.models import Customer
from RESTAPI.serializer import Customer_Serializer
import json
import requests

# Create your views here.

def get_cus_by_id(request,id):
    # cus=Customer.objects.get(id=id)
    cus=Customer.objects.all()
    # cus_native = Customer_Serializer(cus)
    cus_native = Customer_Serializer(cus,many=True)
    cus_json = json.dumps(cus_native.data)
    return HttpResponse(cus_json,content_type='application/json')

def AQI_view(request):
    if request.method=="GET":
        return render (request,'RESTAPI/aqi.html')
    elif request.method=="POST":
        lat=request.POST.get('lat')
        lon=request.POST.get('lon')
        hours=request.POST.get('hours')
        url = "https://air-quality.p.rapidapi.com/forecast/airquality"
        querystring = {"lat":lat,"lon":lon,"hours":hours}
        headers = {'x-rapidapi-host': "air-quality.p.rapidapi.com",'x-rapidapi-key': "b898455d4cmsh814e9850cd2e09cp1c5ec6jsn2fcaf13b1f2a"}
        resp=requests.get(url,params=querystring,headers=headers)
        d1={'response':resp.text}
        return render (request,'RESTAPI/aqi.html',d1)

def AQI_view_ajax(request):
    return render(request,'RESTAPI/aqi_using_ajax.html')