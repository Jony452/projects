from django.shortcuts import render

def login_not_required(func):
    def inner(request):
        if request.user.is_authenticated==False:
            return func(request)
        else:
            return render (request,'SecurePage/home.html')
    return inner


# ese v kar skte hai
# def login_not_required(func):
#     def inner(request,*args, **kwargs):
#         if request.user.is_authenticated==False:
#             return func(request)
#         else:
#             return render (request,'SecurePage/home.html')
#     return inner


#   Ya ese v kar skte hai
# def login_not_required(func):
#     def inner(*args, **kwargs):
#         if args[0].user.is_authenticated==False:
#             return func(args[0])
#         else:
#             return render (args[0],'SecurePage/home.html')
#     return inner