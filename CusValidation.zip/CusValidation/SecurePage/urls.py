from django.urls import path
from .views import *

urlpatterns = [
    path('', homeView,name='Home'),
    path('login/', loginView,name='Login'),
    path('signup/', signupView,name='SignUP'),
    path('secure1/', secure1View,name='Secure1'),
    path('secure2/', secure2View,name='Secure2'),
    path('unsecure1/', unsecure1View,name='UnSecure1'),
    path('unsecure2/', unsecure2View,name='UnSecure2'),
    path('logout/', logoutView,name='Logout'),
]
