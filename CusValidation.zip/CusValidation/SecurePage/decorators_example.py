def NewDiv(func):
    def inner(num1,num2):
        if num2==0:
            print('enter none zero value')
        else:
            return func(num1,num2)
    return inner
@NewDiv
def OldDiv(num1,num2):
    return num1/num2


print(OldDiv(20,0))
