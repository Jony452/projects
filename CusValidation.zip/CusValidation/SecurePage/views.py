from django.http.response import HttpResponse
from django.shortcuts import render
from django.contrib.auth import authenticate, login,logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from Home.forms import CustomerForm
from User.forms import *
from .decorator import login_not_required

# Create your views here.

def homeView(request):
    return render(request,'SecurePage/home.html')
@login_not_required   # in decorator.py
def signupView(request):
    if request.method=="GET":
        cus=CustomerForm(request.POST)
        usr=UserCreationForm(request.POST)
        d1={'form':cus,'cusdata':usr}
        return render(request,'SecurePage/signup.html',context=d1)
    elif request.method=="POST":
        cus=CustomerForm(request.POST)
        usr=UserCreationForm(request.POST)
        d1={'form':cus,'cusdata':usr}
        if cus.is_valid() and usr.is_valid():
            u=usr.save()
            u.save()
            c=cus.save(commit=False)
            c.user=u
            c.save()
            return HttpResponse("added successfully...")
        else:
            return render(request,'SecurePage/signup.html',context=d1)
@login_not_required
def loginView(request):
    if request.method=="GET":
        return render(request,'SecurePage/login.html')
    elif request.method=="POST":
        Username = request.POST.get('username')
        Password = request.POST.get('password')
        u = authenticate(request,username=Username,password=Password)
        if u is not None:
            login(request,user=u)
            return render(request,'SecurePage/home.html')
        else:
            d1={'msg':'username or password not match... '}
            return render(request,'SecurePage/login.html', context=d1)

def logoutView(request):
    if(request.user.is_authenticated):
        logout(request)
    return render(request,'SecurePage/home.html')

@login_required(login_url='Login')
def secure1View(request):
    return render(request,'SecurePage/secure1.html')

@login_required(login_url='Login')    # name of url where want to send user
def secure2View(request):
    return render(request,'SecurePage/secure2.html')

def unsecure1View(request):
    return render(request,'SecurePage/unsecure1.html')
  
def unsecure2View(request):
    return render(request,'SecurePage/unsecure2.html')


       