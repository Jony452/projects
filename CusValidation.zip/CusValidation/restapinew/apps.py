from django.apps import AppConfig


class RestapinewConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'restapinew'
