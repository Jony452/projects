from django.urls import path

from Home.views import post_save_cus_view
from .views import *

urlpatterns = [
    path('getcusbyid/<int:id>',getcus_view),
    path('getaqi/',get_AQI),
    path('ajax/',get_AQI_by_ajax),
    path('postcus/',save_customer_view),
    path('postajax/',Ajax_view_save_cus),
]
