from django.shortcuts import render
import requests
from requests.sessions import Request
import rest_framework

from Home.models import Customer
from restapinew.serializers import customerSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here.
@api_view(http_method_names=['GET'])
def getcus_view(request,id):
    try:
        cus = Customer.objects.get(id=id)
        cus_native=customerSerializer(cus)  # serialization
        resp_api=Response(data=cus_native.data,status=status.HTTP_200_OK)
        return resp_api
    except Exception as e:
        resp_api=Response(data=str(e),status=status.HTTP_404_NOT_FOUND)
        return resp_api


def get_AQI(request):
    if request.method=="GET":
        return render(request,'restapinew/new.html')
    elif request.method=='POST':
        city=request.POST.get('city')
        # lat=request.POST.get('lat')
        # lon=request.POST.get('lon')
        url = "https://air-quality-by-api-ninjas.p.rapidapi.com/v1/airquality"
        querystring = {"city":city}
        headers = {'x-rapidapi-host': "air-quality-by-api-ninjas.p.rapidapi.com",'x-rapidapi-key': "b898455d4cmsh814e9850cd2e09cp1c5ec6jsn2fcaf13b1f2a"}
        resp=requests.get(url,params=querystring,headers=headers)
        d1={'AQI_data':resp.text}
        return render(request,'restapinew/new.html',context=d1)

def get_AQI_by_ajax(request):
    return render(request,'restapinew/AQI_by_ajax.html')

@api_view(http_method_names=['POST'])
def save_customer_view(request):
    cus_serialize=customerSerializer(data= request.data)   #deserialization
    if cus_serialize.is_valid():
        cus=cus_serialize.save()
        return Response(data='customer with id '+str(cus.id)+ ' saved successfully.',status=status.HTTP_200_OK)
    else:
        return Response(data='There is an error while adding customer.',status=status.HTTP_502_BAD_GATEWAY)

def Ajax_view_save_cus(reqest):
    return render(reqest,'restapinew/postUsingAjax.html')