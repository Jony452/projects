from django import forms
from django.db.models import fields
from .models import *



class Customer_Form(forms.ModelForm):
    class Meta:
        model = Customer
        exclude = ['user']
        # fields = "__all__"

    date_of_birth = forms.CharField(widget=forms.TextInput(attrs={'type':'date'}))