from django.urls import path
from.views import *

urlpatterns = [
    path('', userView, name="user" ),
    path('signup/', SignupView, name="signup" ),
    # path('Signup/', SignUpView, name="signup1" ),
    path('write/',WSessionView),
    path('read/',RSessionView),
    
]
