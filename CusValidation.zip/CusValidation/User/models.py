from django.db import models
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import post_save

# Create your models here.

class Customer(models.Model):
    name = models.CharField(max_length=50)
    address = models.TextField(max_length=50)
    date_of_birth = models.DateField(null=True,blank=True)
    create_date = models.DateTimeField(auto_now_add=True)
    update_date = models.DateTimeField(auto_now=True)
    user = models.OneToOneField(User,on_delete=models.CASCADE)


@receiver(post_save, sender=User)             # phle wala(pre_save())- yaha cmd se record add kiye name blank h
def user_post_save_receiver(sender, instance, created, *args, **kwargs):
    # sender: class name from where we are getting signal
    # instance: object of newly saved record
    # created: Boolean value True means Inserted and False means Updated
    print('post save signal called')    
    print('sender', sender)
    print('instance',type(instance) ,instance.username)
    print('created',created)


@receiver(post_save, sender=User)   #baad wala -- yaha agr name na ho to NA dikhega
def user_post_save_receiver(sender,instance,created,*args, **kwargs):
    if created == True:
        cus = Customer()
        cus.user = instance
        cus.name = 'NA'
        cus.address='NA'
        cus.save()
    
