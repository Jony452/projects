from User.forms import Customer_Form
from django.http.response import HttpResponse
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm

# Create your views here.

def userView(request):
    return HttpResponse("This is User App...")


def SignupView(request):
    if request.method == "GET":
        frm_customer=Customer_Form()
        frm_user = UserCreationForm()
        d1={'customer':frm_customer,'user':frm_user}
        return render(request,'User/signupform.html',context=d1)
    elif request.method == "POST":
        frm_customer=Customer_Form(request.POST)
        frm_user = UserCreationForm(request.POST)
        d1={'customer':frm_customer,'user':frm_user}
        if frm_customer.is_valid() and frm_user.is_valid():
            # we can write code here that we want to do before insert user   like ---> pre_save (signal)
            u=frm_user.save()
            # u = frm_user.save(commit=False)     #to active staff
            # u.is_staff = True
            u.save()
            # we can write code here that we want to do after insert user   like ---> post_save (signal)
            c = frm_customer.save(commit=False)
            c.user = u
            c.save()
            return HttpResponse('customer added successfullly....')
        else:
            return render(request,'User/signupform.html',context=d1)


def WSessionView(request):
    if request.method=="POST":
        request.session['Mydata']=request.POST.get('txtdata')
        request.session.set_expiry(10)
    # return render(request,'User/wrSession.html')
    resp = render(request,'User/wrSession.html')
    resp.set_cookie('mycookies','information about cookies',max_age=15)

    return resp

def RSessionView(request):
    data=request.COOKIES.get('mycookies','cookies expired')
    d1={'cookie':data}
    return render(request,'User/readSession.html',context=d1)